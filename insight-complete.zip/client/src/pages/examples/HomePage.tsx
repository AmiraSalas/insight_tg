import HomePage from '../HomePage';

export default function HomePageExample() {
  return <HomePage />;
}
