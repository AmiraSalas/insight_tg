import { EcuadorSection } from '../EcuadorSection';

export default function EcuadorSectionExample() {
  return <EcuadorSection />;
}
